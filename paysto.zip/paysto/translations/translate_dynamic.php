<?php
$_DYNAMIC = array();
$_DYNAMIC["->l('No tax')"] = 'No tax';
$_DYNAMIC["->l('Tax 0%')"] = 'Tax 0%';
$_DYNAMIC["->l('Tax 18%')"] = 'Tax 18%';
$_DYNAMIC["->l('Tax 10%')"] = 'Tax 10%';
$_DYNAMIC["->l('Tax by formula 18/118')"] = 'Tax by formula 18/118';
$_DYNAMIC["->l('Tax by formula 10/110')"] = 'Tax by formula 10/110';
